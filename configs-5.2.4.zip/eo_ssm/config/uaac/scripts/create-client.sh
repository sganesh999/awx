#!/bin/sh

uaac target http://uaa-service:8080/uaa

echo GSS_CALLBACK_URL=$GSS_CALLBACK_URL
echo GSS_LOGOUT_URL=$GSS_LOGOUT_URL
echo GSS_UNAUTHENTICATED_URL=$GSS_UNAUTHENTICATED_URL

GSS_SERVER_SECRET=${GSS_SERVER_SECRET-gss_server_secret}
CLIENT_GUEST_SECRET=${CLIENT_GUEST_SECRET-client_guest_secret}
CLIENT_SCHEDULE_SECRET=${CLIENT_SCHEDULE_SECRET-client_schedule_secret}

# gss_server_id, a special client for authorization_code grant type for end users.
uaac token client get admin -s $UAA_ADMIN_SECRET
if uaac client get gss_server_id; then
    operation="update"
    secret=""
else
    operation="add"
    secret="--secret ${GSS_SERVER_SECRET}"
fi

echo
echo uaac client $operation gss_server_id
uaac client $operation gss_server_id \
--name gss_server_id \
$secret \
--scope "gss.admin, gss.user, gss.guest, openid, shared.assets, opco.north, opco.west, all.assets" \
--authorities "uaa.resource" \
--authorized_grant_types "refresh_token,client_credentials,password,authorization_code" \
--autoapprove "gss.admin, gss.user, gss.guest, openid, shared.assets, opco.north, opco.west, all.assets" \
--access_token_validity 3600 \
--redirect_uri "$GSS_CALLBACK_URL, $GSS_LOGOUT_URL, $GSS_UNAUTHENTICATED_URL" \
--refresh-token-validity 7200

uaac token client get gss_server_id -s $GSS_SERVER_SECRET
uaac context gss_server_id

# Standard clients
# client_admin
uaac token client get admin -s $UAA_ADMIN_SECRET
if uaac client get client_admin; then
    operation="update"
    secret=""
else
    operation="add"
    secret="--secret client_admin"
fi

echo
echo uaac client $operation client_admin
uaac client $operation client_admin \
--name client_admin \
$secret \
--scope "gss.admin, all.assets" \
--authorities "gss.admin, all.assets" \
--authorized_grant_types "client_credentials"

uaac token client get client_admin -s client_admin
uaac context client_admin

# client_user
uaac token client get admin -s $UAA_ADMIN_SECRET
if uaac client get client_user; then
    operation="update"
    secret=""
else
    operation="add"
    secret="--secret client_user"
fi

echo
echo uaac client $operation client_user
uaac client $operation client_user \
$secret \
--name client_user \
--scope "gss.user, shared.assets" \
--authorities "gss.user, shared.assets" \
--authorized_grant_types "client_credentials"

uaac token client get client_user -s client_user
uaac context client_user

# client_both
uaac token client get admin -s $UAA_ADMIN_SECRET
if uaac client get client_both; then
    operation="update"
    secret=""
else
    operation="add"
    secret="--secret client_both"
fi

echo
echo uaac client $operation client client_both
uaac client $operation client_both \
--name client_both \
$secret \
--scope "gss.user, gss.admin, all.assets" \
--authorities "gss.user, gss.admin, all.assets" \
--authorized_grant_types "client_credentials"

uaac token client get client_both -s client_both
uaac context client_both

# client_none
uaac token client get admin -s $UAA_ADMIN_SECRET
if uaac client get client_none; then
    operation="update"
    secret=""
else
    operation="add"
    secret="--secret client_none"
fi

echo
echo uaac client $operation client_none
uaac client $operation client_none \
$secret \
--name client_none \
--scope "" \
--authorities "" \
--authorized_grant_types "client_credentials"

uaac token client get client_none -s client_none
uaac context client_none

# client_guest
uaac token client get admin -s $UAA_ADMIN_SECRET
if uaac client get client_guest; then
    operation="update"
    secret=""
else
    operation="add"
    secret="--secret ${CLIENT_GUEST_SECRET}"
fi

echo
echo uaac client $operation client_guest
uaac client $operation client_guest \
$secret \
--name client_guest \
--scope "gss.guest" \
--authorities "gss.guest" \
--authorized_grant_types "client_credentials"

uaac token client get client_guest -s $CLIENT_GUEST_SECRET
uaac context client_guest

# client_schedule
uaac token client get admin -s $UAA_ADMIN_SECRET
if uaac client get client_schedule; then
    operation="update"
    secret=""
else
    operation="add"
    secret="--secret ${CLIENT_SCHEDULE_SECRET}"
fi

echo
echo uaac client $operation client_schedule
uaac client $operation client_schedule \
--name client_schedule \
$secret \
--scope "gss.admin, all.assets" \
--authorities "gss.admin, all.assets" \
--authorized_grant_types "client_credentials"

uaac token client get client_schedule -s $CLIENT_SCHEDULE_SECRET
uaac context client_schedule

# client_north
uaac token client get admin -s $UAA_ADMIN_SECRET
if uaac client get client_north; then
    operation="update"
    secret=""
else
    operation="add"
    secret="--secret client_north"
fi

echo
echo uaac client $operation client_north
uaac client $operation client_north \
$secret \
--name client_north \
--scope "gss.user, opco.north, shared.assets" \
--authorities "gss.user, opco.north, shared.assets" \
--authorized_grant_types "client_credentials"

uaac token client get client_north -s client_north
uaac context client_north

# client_west
uaac token client get admin -s $UAA_ADMIN_SECRET
if uaac client get client_west; then
    operation="update"
    secret=""
else
    operation="add"
    secret="--secret client_west"
fi

echo
echo uaac client $operation client_west
uaac client $operation client_west \
$secret \
--name client_west \
--scope "gss.user, opco.west, shared.assets" \
--authorities "gss.user, opco.west, shared.assets" \
--authorized_grant_types "client_credentials"

uaac token client get client_west -s client_west
uaac context client_west