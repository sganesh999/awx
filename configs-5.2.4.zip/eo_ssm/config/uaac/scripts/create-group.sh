#!/bin/sh
# create uaa groups from data in in the ../data/create-group file
# delimiter is |

myname=`basename "$0"`
datafilename=$(echo "$myname" | cut -f 1 -d '.')
datafile=../data/$datafilename

if [ ! -f $datafile ];
then
  exit 0
fi

uaac target http://uaa-service:8080/uaa
uaac token client get admin -s $UAA_ADMIN_SECRET

IFS=$'\n'
for line in `cat $datafile`
do
  var=`echo $line | awk -F "|" '{print "group=\""$1"\""}'`
  eval $var

  if [ -z "$group" ] || [ "$group" == "GROUP_NAME" ];
  then
    continue
  fi

  echo create group \"$group\"
  uaac group add $group
done
