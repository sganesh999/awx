#!/bin/sh
# the starting point
# must create members after groups and users are created.

sh create-client.sh
sh create-group.sh
sh create-user.sh
sh create-member.sh

if [ -f "create-external-group-mapping.sh" ];
then
  sh create-external-group-mapping.sh
fi

if [ -f "fix-uaa-client-for-saml.sh" ];
then
  sh fix-uaa-client-for-saml.sh
fi

exit 0
